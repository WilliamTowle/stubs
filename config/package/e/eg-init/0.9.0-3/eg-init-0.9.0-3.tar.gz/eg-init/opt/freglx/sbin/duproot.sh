#!/bin/sh
# franki/earlgrey /root/bin/duproot.sh, WmT 17/02/2004

ANNOUNCE=

do_rdup()
{
	FROMDIR=$1
	TODIR=$2
	DIRLIST=`/bin/ls -d1 ${FROMDIR}/??? ${FROMDIR}/????`

	KEEPFILES='etc/passwd etc/group etc/fstab'
	DO_KEEP=n
	for KF in ${KEEPFILES} ; do
		[ -r ${TODIR}/${KF} ] && DO_KEEP=y
	done

	echo -n "Preserving: "
	if [ "${DO_KEEP}" = 'y' ] ; then
		 ( cd $TODIR && tar cvf .preserve.tar ${KEEPFILES} ) | while read FILE ; do
		 	echo -n "."
		 done
	fi
	echo

	echo -n "Making directories:"
	set -- $DIRLIST
	while [ "$1" ] ; do
		DIR=`echo $1 | sed 's%^/%%'`
		echo -n " $DIR"
		shift
		
		[ -d ${FROMDIR}/$DIR ] && $ANNOUNCE mkdir -p $TODIR/$DIR
	done
	echo

	echo -n "Copying:"
	set -- $DIRLIST
	while [ "$1" ] ; do
		DIR=`echo $1 | sed 's%^/%%'`
		echo -n " $DIR"
		shift

		case $DIR in
		bin|boot|dev|etc|lib|opt|root|sbin|usr|var)
			( cd $FROMDIR && tar cf - $DIR ) | ( cd $TODIR && tar xf - )
			;;
		mnt|proc|tmp)	;; # ignore
		*)	echo -n "?"
		esac
	done
	echo

	echo -n "Restoring: "
	if [ "${DO_KEEP}" = 'y' ] ; then
		( cd $TODIR && tar xvf .preserve.tar ) | while read FILE ; do
			echo -n "."
		done
	fi
	echo
}

do_rootgen()
{
	FSTYPE=$1
	DEVNAME=$2
	MNTPT=$3

	if [ -d $MNTPT ] ; then
		HADMNT=y
	else
		HADMNT=n
		mkdir $MNTPT
	fi

	SUCCESS=assumed
	(
	mount -t $FSTYPE $DEVNAME $MNTPT || exit 1
	if [ $FSTYPE = 'umsdos' ] ; then
		[ -d $MNTPT/linux ] || mkdir -p $MNTPT/linux
		umssync $MNTPT/linux || SUCCESS=n
		[ $SUCCESS != 'n' ] && do_rdup / $MNTPT/linux
	else
		do_rdup / $MNTPT
	fi
	umount $MNTPT
	[ $SUCCESS != 'n' ]
	) || SUCCESS=n
	
	[ $HADMNT = 'n' ] && rmdir $MNTPT
	[ $SUCCESS != 'n' ]
}

if [ "$1" ] ; then
	FSTYPE=$1
	shift
else
	echo "$0: FSTYPE (or DEVNAME, MNTPT) unsupplied"
	exit 1
fi

if [ "$1" ] ; then
	DEVNAME=$1
	shift
else
	echo "$0: DEVNAME (or MNTPT) unsupplied"
	exit 1
fi

MNTPT=$1
[ "$MNTPT" ] || MNTPT=/mnt/mnt.$$

do_rootgen $FSTYPE $DEVNAME $MNTPT || exit 1
echo "$0: OK"
