#!/bin/sh

insert_archive()
{
	ARCHIVE=$1
	MODULE=$2
	TMPDIR=/tmp

	MODPATH='modules/'`uname -r`
	case ${MODULE} in
	*/*)	;;
	*)	[ "$SUBCAT" ] || SUBCAT=net
		MODPATH=${MODPATH}/${SUBCAT}/
		;;
	esac

	cat $ARCHIVE | ( cd $TMPDIR && tar xzf - ${MODPATH}/${MODULE} ) || STATUS="module extract failed"
	insert_file ${TMPDIR}/${MODPATH}/${MODULE}
	rm -rf $TMPDIR/modules
}

insert_file()
{
	MODFILE=$1
	[ -s ${MODFILE} ] && insmod ${MODFILE}
}

try_modinst()
{
	LOCATION=$1
	MODULE=$2

	if [ -r $LOCATION/modules.tgz ] ; then
		insert_archive $LOCATION/modules.tgz $MODULE
	elif [ -d $LOCATION/$MODULE ] ; then
		insert_file $LOCATION/$MODULE
	else
		exit 1
	fi
}

if [ "$1" ] ; then
	MODULE=$1
	shift
else
	echo "$0: Expected MODULE"
	exit 1
fi

if [ -z "$1" ] ; then
	echo "$0: Expected ARCHIVE/DIRECTORY"
	exit 1
else
	OK=n
	while [ "$1" ] ; do
		LOCATION=$1
		shift

		if [ $OK = 'n' ] ; then
			( try_modinst $LOCATION $MODULE ) && OK=y
		fi
	done
fi
