#!/bin/sh

PASS="\r [  \033[32mOK\033[0m\t]"
FAIL="\r [ \033[31mFAIL\033[0m\t]"
SKIP="\r [ \033[33mSKIP\033[0m\t]"

if [ -z "$1" ] ; then
	echo "No COMMAND"
	exit 1
else
	COMMAND=$1
	shift
fi

case $COMMAND in
announce)	echo -n -e " [\t] $*"	;;
pass)		echo -e "$PASS"	;;
skip)		echo -e "$SKIP"	;;
fail)		echo -e "$FAIL"	;;
esac
